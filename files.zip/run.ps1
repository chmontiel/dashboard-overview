# run.ps1
# -------
# Main entry point — runs the full automation pipeline:
#
#   1. Load env vars     → env.base.ps1
#   2. Build config      → config.ps1
#   3. Create folder     → create-folder.ps1  (ensures Clients/{ClientName}/ exists)
#   4. Update dashboard  → update_dashboard.py (copies + customizes the JSON)
#   5. Send dashboard    → send-dashboard.ps1  (uploads to Grafana)
#
# Usage:
#   1. Fill in env.base.ps1 with your values
#   2. cd tools/
#   3. .\run.ps1
#
# Prerequisites:
#   - "Clients" folder must already exist in Grafana
#   - Service account token with Editor+ privileges
#   - Python 3 installed (for update_dashboard.py)

$ErrorActionPreference = "Stop"

# Set-Location $PSScriptRoot → ensures relative paths work from any directory
Set-Location $PSScriptRoot

Write-Host "============================================================"
Write-Host "Grafana Dashboard Automation"
Write-Host "============================================================"

# ── Step 1: Load environment variables ────────────────────────────────────
# The dot-source operator (.) runs a script in the CURRENT scope
Write-Host "`n[1/5] Loading environment variables..."
. .\env.base.ps1

# ── Step 2: Build config ─────────────────────────────────────────────────
Write-Host "[2/5] Building config..."
$config = . .\config.ps1

# Validate required fields
if ([string]::IsNullOrWhiteSpace($config.GrafanaUrl)) { throw "GrafanaUrl is missing." }
if ([string]::IsNullOrWhiteSpace($config.Token))      { throw "Token is missing." }
if ([string]::IsNullOrWhiteSpace($config.ClientName))  { throw "ClientName is missing." }
if ([string]::IsNullOrWhiteSpace($config.SubscriptionId)) { throw "SubscriptionId is missing." }
if ([string]::IsNullOrWhiteSpace($config.DashboardsDir))  { throw "DashboardsDir is missing." }

Write-Host "  Client:       $($config.ClientName)"
Write-Host "  Subscription: $($config.SubscriptionId)"
Write-Host "  Grafana:      $($config.GrafanaUrl)"
Write-Host "  Dashboards:   $($config.DashboardsDir)"

# Ensure subdirectories exist
foreach ($dir in @($config.TemplatesDir, $config.OutputDir, $config.PayloadsDir)) {
    if (-not (Test-Path $dir)) {
        New-Item -ItemType Directory -Path $dir -Force | Out-Null
        Write-Host "  Created: $dir"
    }
}

# ── Step 3: Create folder ────────────────────────────────────────────────
Write-Host "`n[3/5] Setting up folder: Clients/$($config.ClientName)..."
. .\create-folder.ps1 -Config $config

# ── Step 4: Update dashboard (Python) ────────────────────────────────────
# Runs the Python script which reads the same env vars.
Write-Host "`n[4/5] Creating client dashboard copy..."
python .\update_dashboard.py

# $LASTEXITCODE → the exit code of the last external program that ran
if ($LASTEXITCODE -ne 0) {
    throw "update_dashboard.py failed with exit code $LASTEXITCODE"
}

# ── Step 5: Send dashboard ───────────────────────────────────────────────
Write-Host "`n[5/5] Uploading dashboard to Grafana..."
. .\send-dashboard.ps1 -Config $config

# ── Done ─────────────────────────────────────────────────────────────────
Write-Host "`n============================================================"
Write-Host "Done!"
Write-Host "============================================================"
