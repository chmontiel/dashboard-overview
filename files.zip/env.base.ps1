# env.base.ps1
# ------------
# Set these environment variables before running.
# You can also set them in your shell/terminal directly.

$env:Grafana_Url     = ""           # Base URL, e.g. "https://grafana.example.com"
$env:Token           = ""           # Service account token (Editor+ privileges)
$env:Client_Name     = ""           # Display name, e.g. "Acme Corp"
$env:Subscription    = ""           # Azure subscription ID
$env:Namespace       = "default"    # Grafana namespace (usually "default")
$env:Dashboards_Dir  = ""           # Path to dashboards/ directory, e.g. "C:\project\kql-grafna\dashboards"
