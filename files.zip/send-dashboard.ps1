# send-dashboard.ps1
# -------------------
# Uploads the client-specific dashboard JSON to Grafana, placing it in the
# client's subfolder.
#
# Steps:
#   1. Load the updated dashboard JSON from output/.
#   2. Strip export-only fields (__inputs, __elements, __requires).
#   3. Check if a dashboard with this title already exists.
#      - If yes: prompt the user (y/n) to overwrite.
#      - If no:  create it.
#   4. POST to /api/dashboards/db with the correct folderUid.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"

# --- Validate that the updated dashboard file exists -------------------------
if (-not (Test-Path $Config.OutputDashboard)) {
    throw "Updated dashboard file not found: $($Config.OutputDashboard)"
}

# --- Build headers (no Content-Type here — we pass it via -ContentType) ------
$headers = @{
    Authorization = "Bearer $($Config.Token)"
    Accept        = "application/json"
}


# =============================================================================
# STEP 1: Load the dashboard JSON from disk
# =============================================================================
# Get-Content -Raw → reads the entire file as a single string (not line-by-line)
# ConvertFrom-Json → parses JSON into a PowerShell object (like Python's json.load)

Write-Host "Loading dashboard from: $($Config.OutputDashboard)"
$dashboard = Get-Content -Raw -Path $Config.OutputDashboard | ConvertFrom-Json


# =============================================================================
# STEP 2: Strip export-only fields
# =============================================================================
# When you export a dashboard from Grafana's UI, it adds __inputs, __elements,
# and __requires. These cause errors if sent to the API.

foreach ($field in @('__inputs', '__elements', '__requires')) {
    if ($dashboard.PSObject.Properties.Name -contains $field) {
        $dashboard.PSObject.Properties.Remove($field)
    }
}

# Ensure import-safe values
$dashboard.id      = $null    # null → tells the API this is a new dashboard
$dashboard.version = 0        # reset version counter

# Remove uid if it still exists (Grafana assigns one)
if ($dashboard.PSObject.Properties.Name -contains 'uid') {
    $dashboard.PSObject.Properties.Remove('uid')
}


# =============================================================================
# STEP 3: Check if dashboard already exists
# =============================================================================
# GET /api/search — search for dashboards by title
#   type=dash-db → only return dashboards (not folders)

Write-Host "Checking for existing dashboard: '$($Config.DashboardTitle)' ..."

$searchUri = "$($Config.GrafanaUrl)/api/search?type=dash-db&query=$([uri]::EscapeDataString($Config.DashboardTitle))"
$searchResults = Invoke-RestMethod -Method Get -Uri $searchUri -Headers $headers

# Filter for exact title match
$existing = $searchResults | Where-Object {
    $_.title -eq $Config.DashboardTitle -and $_.type -eq "dash-db"
}

$overwrite = $false

if ($null -ne $existing) {
    # Read-Host → prompts the user for input in the terminal
    $answer = Read-Host "Dashboard '$($Config.DashboardTitle)' already exists. Overwrite? (y/n)"
    $answer = $answer.Trim().ToLower()

    if ($answer -ne "y" -and $answer -ne "yes") {
        Write-Host "Skipping dashboard upload."
        return
    }

    $overwrite = $true
}


# =============================================================================
# STEP 4: Submit to Grafana
# =============================================================================
# POST /api/dashboards/db — create or update a dashboard
#
# Request body fields:
#   dashboard → the full dashboard JSON object
#   folderUid → which folder to place the dashboard in
#   overwrite → if $true, replaces an existing dashboard
#   message   → commit message shown in Grafana's version history

$bodyObject = @{
    dashboard = $dashboard
    folderUid = $Config.FolderUid     # Set by create-folder.ps1
    overwrite = $overwrite
    message   = "Automated deployment via scripts"
}

$body = $bodyObject | ConvertTo-Json -Depth 100

# --- Save payload for debugging ---------------------------------------------
# Ensure payloads/ directory exists
$payloadsDir = $Config.PayloadsDir
if (-not (Test-Path $payloadsDir)) {
    New-Item -ItemType Directory -Path $payloadsDir -Force | Out-Null
}

$body | Set-Content -Path $Config.PayloadFile -Encoding UTF8
Write-Host "Debug: saved payload to $($Config.PayloadFile)"

# --- Send the request --------------------------------------------------------
# -ContentType parameter → sets the Content-Type header properly with charset
#   Using this instead of putting Content-Type in $headers avoids BOM encoding issues
$createUri = "$($Config.GrafanaUrl)/api/dashboards/db"

try {
    $response = Invoke-RestMethod -Method Post -Uri $createUri -Headers $headers -Body $body -ContentType "application/json; charset=utf-8"
    Write-Host "Dashboard submitted: $($Config.DashboardTitle)"

    if ($response.url) {
        Write-Host "  URL: $($Config.GrafanaUrl)$($response.url)"
    }
    if ($response.uid) {
        Write-Host "  UID: $($response.uid)"
    }
}
catch {
    Write-Host "Dashboard submit failed."

    # $_.Exception.Response → the HTTP response from the failed request
    if ($null -ne $_.Exception.Response) {
        $responseStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($responseStream)
        $responseBody = $reader.ReadToEnd()

        Write-Host "  Status: $($_.Exception.Response.StatusCode)"
        Write-Host "  Body:   $responseBody"
    }

    Write-Host "  Payload saved at: $($Config.PayloadFile)"
    throw
}
