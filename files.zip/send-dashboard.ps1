# send-dashboard.ps1
# -------------------
# Uploads the client-specific dashboard JSON to Grafana, placing it in the
# client's subfolder.
#
# Steps:
#   1. Load the updated dashboard JSON from disk.
#   2. Strip export-only fields (__inputs, __elements, __requires).
#   3. Check if a dashboard with this title already exists.
#      - If yes: prompt the user (y/n) to overwrite.
#      - If no:  create it.
#   4. POST to /api/dashboards/db with the correct folderUid.
#
# Common "bad request" causes:
#   - Sending a non-null 'id' field (must be $null for new dashboards)
#   - Missing or wrong folderUid
#   - Export-only fields like __inputs still present

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"

# --- Validate that the updated dashboard file exists -------------------------
if (-not (Test-Path $Config.OutputDashboard)) {
    throw "Updated dashboard file not found: $($Config.OutputDashboard)"
}

# --- Build headers -----------------------------------------------------------
$headers = @{
    Authorization  = "Bearer $($Config.Token)"
    Accept         = "application/json"
    "Content-Type" = "application/json"
}


# =============================================================================
# STEP 1: Load the dashboard JSON from disk
# =============================================================================
# Get-Content -Raw → reads the entire file as a single string (not line-by-line)
# ConvertFrom-Json → parses JSON into a PowerShell object (like Python's json.load)

Write-Host "Loading dashboard from: $($Config.OutputDashboard)"
$dashboard = Get-Content -Raw -Path $Config.OutputDashboard | ConvertFrom-Json


# =============================================================================
# STEP 2: Strip export-only fields
# =============================================================================
# When you export a dashboard from Grafana's UI, it adds __inputs, __elements,
# and __requires. These are metadata for the import wizard and cause errors
# if sent to the API directly.
#
# PSObject.Properties → collection of all properties on the object
# .Name               → the property name
# .Remove()           → deletes the property

foreach ($field in @('__inputs', '__elements', '__requires')) {
    if ($dashboard.PSObject.Properties.Name -contains $field) {
        $dashboard.PSObject.Properties.Remove($field)
    }
}

# Ensure import-safe values
$dashboard.id      = $null    # null → tells the API this is a new dashboard
$dashboard.version = 0        # reset version counter


# =============================================================================
# STEP 3: Check if dashboard already exists
# =============================================================================
# GET /api/search — search for dashboards by title
#   type=dash-db → only return dashboards (not folders)
#
# [uri]::EscapeDataString() → URL-encodes the title so special characters don't break the URL

Write-Host "Checking for existing dashboard: '$($Config.DashboardTitle)' ..."

$searchUri = "$($Config.GrafanaUrl)/api/search?type=dash-db&query=$([uri]::EscapeDataString($Config.DashboardTitle))"
$searchResults = Invoke-RestMethod -Method Get -Uri $searchUri -Headers $headers

# Filter for exact title match
$existing = $searchResults | Where-Object {
    $_.title -eq $Config.DashboardTitle -and $_.type -eq "dash-db"
}

$overwrite = $false

if ($null -ne $existing) {
    # --- Prompt user to overwrite ------------------------------------------------
    # Read-Host → prompts the user for input in the terminal
    # .Trim().ToLower() → normalize the answer for comparison
    $answer = Read-Host "Dashboard '$($Config.DashboardTitle)' already exists. Overwrite? (y/n)"
    $answer = $answer.Trim().ToLower()

    if ($answer -ne "y" -and $answer -ne "yes") {
        Write-Host "Skipping dashboard upload."
        return
    }

    $overwrite = $true
}


# =============================================================================
# STEP 4: Submit to Grafana
# =============================================================================
# POST /api/dashboards/db — create or update a dashboard
#
# Request body fields:
#   dashboard → the full dashboard JSON object
#   folderUid → which folder to place the dashboard in
#   overwrite → if $true, replaces an existing dashboard with the same title/uid
#   message   → commit message shown in Grafana's dashboard version history

$bodyObject = @{
    dashboard = $dashboard
    folderUid = $Config.FolderUid     # Set by create-folder.ps1
    overwrite = $overwrite
    message   = "Automated deployment via scripts"
}

# ConvertTo-Json -Depth 100 → deep serialization (dashboards have deeply nested objects)
$body = $bodyObject | ConvertTo-Json -Depth 100

# Save the request body for debugging if something goes wrong
$debugPath = Join-Path (Split-Path -Parent $Config.OutputDashboard) "dashboard-submit-body.json"
$body | Set-Content -Path $debugPath -Encoding UTF8
Write-Host "Debug: saved request body to $debugPath"

$createUri = "$($Config.GrafanaUrl)/api/dashboards/db"

# --- Send the request --------------------------------------------------------
# try/catch → PowerShell's error handling (like Python's try/except)
# Invoke-RestMethod → sends HTTP request, parses JSON response automatically
try {
    $response = Invoke-RestMethod -Method Post -Uri $createUri -Headers $headers -Body $body
    Write-Host "Dashboard submitted: $($Config.DashboardTitle)"

    if ($response.url) {
        Write-Host "  URL: $($Config.GrafanaUrl)$($response.url)"
    }
    if ($response.uid) {
        Write-Host "  UID: $($response.uid)"
    }
}
catch {
    Write-Host "Dashboard submit failed."

    # --- Print error details for debugging -----------------------------------
    # $_.Exception.Response → the HTTP response object from the failed request
    # GetResponseStream()   → gets the response body as a stream
    # StreamReader          → reads the stream into a string
    if ($null -ne $_.Exception.Response) {
        $responseStream = $_.Exception.Response.GetResponseStream()
        $reader = New-Object System.IO.StreamReader($responseStream)
        $responseBody = $reader.ReadToEnd()

        Write-Host "  Status: $($_.Exception.Response.StatusCode)"
        Write-Host "  Body:   $responseBody"
    }

    Write-Host "  Debug body saved at: $debugPath"
    throw
}
