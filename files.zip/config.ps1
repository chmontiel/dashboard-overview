# config.ps1
# ----------
# Reads environment variables and builds a config hashtable used by all scripts.
# Returns a hashtable via implicit output (PowerShell returns the last expression).

# --- Read client name from env var ------------------------------------------
$clientName = $env:Client_Name

if ([string]::IsNullOrWhiteSpace($clientName)) {
    throw "Client_Name environment variable is missing."
}

# --- Read dashboards directory ----------------------------------------------
$dashboardsDir = $env:Dashboards_Dir

if ([string]::IsNullOrWhiteSpace($dashboardsDir)) {
    throw "Dashboards_Dir environment variable is missing."
}

# --- Build a URL/filesystem-safe version of the client name -----------------
# ToLower()         → lowercase everything
# -replace pattern  → swap any non-alphanumeric characters for hyphens
# .Trim('-')        → remove leading/trailing hyphens
# Example: "Acme Corp" → "acme-corp"
$safeName = $clientName.ToLower().Trim() -replace '[^a-z0-9]+', '-'
$safeName = $safeName.Trim('-')

# --- Return the config hashtable --------------------------------------------
@{
    # Connection settings
    GrafanaUrl      = $env:Grafana_Url
    Token           = $env:Token
    Namespace       = if ($env:Namespace) { $env:Namespace } else { "default" }

    # Client info
    ClientName      = $clientName
    SubscriptionId  = $env:Subscription

    # Folder settings (subfolder under "Clients/")
    ParentFolder    = "Clients"
    FolderTitle     = $clientName
    FolderUid       = ""                # Blank — looked up or created by create-folder.ps1

    # Dashboard directory structure
    #   dashboards/
    #     templates/    ← source of truth (never modified)
    #     output/       ← client-specific copies
    #     payloads/     ← API request bodies (for debugging)
    DashboardsDir   = $dashboardsDir
    TemplatesDir    = Join-Path $dashboardsDir "templates"
    OutputDir       = Join-Path $dashboardsDir "output"
    PayloadsDir     = Join-Path $dashboardsDir "payloads"

    # File paths
    SourceDashboard = Join-Path $dashboardsDir "templates" "Client-Overview.json"
    OutputDashboard = Join-Path $dashboardsDir "output" "$safeName-overview.json"
    PayloadFile     = Join-Path $dashboardsDir "payloads" "$safeName-submit-body.json"

    # Dashboard metadata
    DashboardTitle  = "$clientName-Overview"

    # Template variable settings
    # 0 = visible, 1 = label only, 2 = fully hidden
    HideSubVariable = 2
}
