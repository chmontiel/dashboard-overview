# config.ps1
# ----------
# Reads environment variables and builds a config hashtable used by all scripts.
# Returns a hashtable via implicit output (PowerShell returns the last expression).

# --- Read client name from env var ------------------------------------------
$clientName = $env:Client_Name

# Throw an error early if it's missing
if ([string]::IsNullOrWhiteSpace($clientName)) {
    throw "Client_Name environment variable is missing."
}

# --- Build a URL/filesystem-safe version of the client name -----------------
# ToLower()         → lowercase everything
# -replace pattern  → swap any non-alphanumeric characters for hyphens
# .Trim('-')        → remove leading/trailing hyphens
# Example: "Acme Corp" → "acme-corp"
$safeName = $clientName.ToLower().Trim() -replace '[^a-z0-9]+', '-'
$safeName = $safeName.Trim('-')

# --- Return the config hashtable --------------------------------------------
# This is used by run.ps1 and passed to each script via the -Config parameter.
@{
    # Connection settings
    GrafanaUrl      = $env:Grafana_Url
    Token           = $env:Token
    Namespace       = if ($env:Namespace) { $env:Namespace } else { "default" }

    # Client info
    ClientName      = $clientName
    SubscriptionId  = $env:Subscription

    # Folder settings (subfolder under "Clients/")
    ParentFolder    = "Clients"
    FolderTitle     = $clientName
    FolderUid       = ""                # Blank — Grafana assigns one, or we look it up

    # Dashboard file paths (relative to tools/)
    SourceDashboard = "..\dashboards\Client-Overview.json"
    OutputDashboard = "..\dashboards\$safeName-overview.json"

    # Dashboard metadata
    DashboardTitle  = "$clientName-Overview"

    # Template variable settings
    # 0 = visible, 1 = label only, 2 = fully hidden
    HideSubVariable = 2
}
