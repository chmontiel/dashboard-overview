# create-folder.ps1
# ------------------
# Ensures the client's subfolder exists under the "Clients" parent folder.
#
# Steps:
#   1. Search for the "Clients" parent folder — STOP if it doesn't exist.
#   2. Check if a subfolder named after the client already exists.
#      - If yes: log it and continue.
#      - If no:  create it under Clients/.
#
# The folder UID is stored back into $Config.FolderUid so later scripts
# (send-dashboard.ps1) know where to upload the dashboard.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

# Stop on any error (don't silently continue)
$ErrorActionPreference = "Stop"

# --- Build common headers for Grafana API calls -----------------------------
$headers = @{
    Authorization  = "Bearer $($Config.Token)"
    Accept         = "application/json"
}

$headersWithContent = @{
    Authorization  = "Bearer $($Config.Token)"
    Accept         = "application/json"
    "Content-Type" = "application/json"
}


# =============================================================================
# STEP 1: Find the "Clients" parent folder
# =============================================================================
# GET /api/search — search Grafana for folders matching a title.
#   type=dash-folder → only return folders (not dashboards)
#   query=...        → search by title (fuzzy match, so we filter for exact)

Write-Host "Looking for parent folder: '$($Config.ParentFolder)' ..."

$searchUri = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$([uri]::EscapeDataString($Config.ParentFolder))"

# Invoke-RestMethod sends an HTTP request and automatically parses JSON responses.
$results = Invoke-RestMethod -Method Get -Uri $searchUri -Headers $headers

# Filter for an exact title match (the API search is fuzzy)
# Where-Object { } → filters an array, keeping only items where the condition is true
# .title           → accesses the "title" property of each result
$parentFolder = $results | Where-Object { $_.title -eq $Config.ParentFolder }

# If no match, the Clients folder doesn't exist — can't continue
if ($null -eq $parentFolder) {
    throw "Parent folder '$($Config.ParentFolder)' not found in Grafana. Please create it first."
}

# If multiple matches (unlikely), just take the first one
# @() wraps the result in an array so [0] always works, even for a single item
$parentUid = @($parentFolder)[0].uid
Write-Host "Found parent folder: '$($Config.ParentFolder)' (uid: $parentUid)"


# =============================================================================
# STEP 2: Check if the client subfolder already exists
# =============================================================================
# Search within the parent folder using folderUIDs filter

Write-Host "Checking for existing subfolder: '$($Config.FolderTitle)' ..."

$subSearchUri = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$([uri]::EscapeDataString($Config.FolderTitle))&folderUIDs=$parentUid"

$subResults = Invoke-RestMethod -Method Get -Uri $subSearchUri -Headers $headers

# Filter for exact title match again
$existingFolder = $subResults | Where-Object { $_.title -eq $Config.FolderTitle }

if ($null -ne $existingFolder) {
    $existingUid = @($existingFolder)[0].uid
    Write-Host "Folder already exists: '$($Config.FolderTitle)' (uid: $existingUid)"
    Write-Host "  Location: $($Config.ParentFolder)/$($Config.FolderTitle)"

    # Store the UID so send-dashboard.ps1 can use it
    $Config.FolderUid = $existingUid
    return
}


# =============================================================================
# STEP 3: Create the client subfolder
# =============================================================================
# POST /api/folders — create a new folder.
#   title     → display name of the folder
#   parentUid → UID of the parent folder (nests it under Clients/)

Write-Host "Creating subfolder: '$($Config.FolderTitle)' under '$($Config.ParentFolder)' ..."

$createUri = "$($Config.GrafanaUrl)/api/folders"

# ConvertTo-Json → converts a PowerShell hashtable to a JSON string
# -Depth 10      → how deep to serialize nested objects (default is 2, which is too shallow)
$body = @{
    title     = $Config.FolderTitle
    parentUid = $parentUid
} | ConvertTo-Json -Depth 10

$created = Invoke-RestMethod -Method Post -Uri $createUri -Headers $headersWithContent -Body $body

Write-Host "Created folder: '$($created.title)' (uid: $($created.uid))"
Write-Host "  Location: $($Config.ParentFolder)/$($created.title)"

# Store the UID so send-dashboard.ps1 can use it
$Config.FolderUid = $created.uid
