# send-dashboard.ps1
# ==================
# Uploads ONE dashboard to Grafana. The behavior depends on
# $Config.DashboardType:
#
#   "homepage" -> per-client dashboard
#                 - runs update_sub_var.py to stamp in client name + subscription
#                 - strips the UID so Grafana assigns a new one
#                 - uploads to the client's subfolder under Client-Homepages
#                 - that subfolder MUST already exist (run CreateFolder first)
#
#   "shared"   -> golden template
#                 - UID is PRESERVED exactly as-is (it's the stable identity
#                   that homepage dashboards link to via URL)
#                 - template JSON is uploaded without modification
#                 - uploads to Shared / Client-Dashboards
#                 - both of those folders MUST already exist
#
# Both paths end at a POST to /api/dashboards/db. If a dashboard with
# the same title already exists in the target folder, the user is
# prompted for y/n before overwriting.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"


# ====================================================================
# Common HTTP headers (GET-style; used for all searches and for POSTs
# where we pass -ContentType on the Invoke-RestMethod call directly)
# ====================================================================
$headers = @{
    Authorization = "Bearer $($Config.Token)"
    Accept        = "application/json"
}


# ====================================================================
# Step 1 - Validate the inputs every branch needs
# ====================================================================
# DashboardType, DashboardKey, and Dashboards_Dir are required for both
# flows. Type-specific requirements (e.g. Subscription for homepage)
# are validated inside each branch.

$dashboardType = $Config.DashboardType

if ([string]::IsNullOrWhiteSpace($dashboardType)) {
    throw "Dashboard_Type is missing. Set it in env.base.ps1 (homepage|shared) or pass -DashboardType."
}
if ($dashboardType -ne "homepage" -and $dashboardType -ne "shared") {
    throw "Dashboard_Type '$dashboardType' is invalid. Must be 'homepage' or 'shared'."
}
if ([string]::IsNullOrWhiteSpace($Config.DashboardKey)) {
    throw "Dashboard_Key is missing. Set it in env.base.ps1 or pass -DashboardKey."
}
if ([string]::IsNullOrWhiteSpace($Config.DashboardsDir)) {
    throw "Dashboards_Dir is missing. Set it in env.base.ps1."
}


# ====================================================================
# Step 2 - Prepare the dashboard JSON and resolve the target folder
# ====================================================================
# The two type branches do different work here but both produce:
#   $dashboard       - the PowerShell object to upload
#   $targetFolderUid - the UID of the folder the dashboard goes into
#   $uploadTitle     - the dashboard title (used for existence checks)

if ($dashboardType -eq "homepage") {

    # ----------------------------------------------------------------
    # HOMEPAGE branch
    # ----------------------------------------------------------------
    Write-Host "Dashboard type: HOMEPAGE (per-client)"

    # Validate homepage-specific requirements
    if ([string]::IsNullOrWhiteSpace($Config.SubscriptionId)) {
        throw "Subscription is missing. Required for homepage dashboards."
    }
    if (-not (Test-Path $Config.HomepageTemplatePath)) {
        throw "Homepage template not found: $($Config.HomepageTemplatePath)"
    }

    # Ensure output/payloads directories exist so update_sub_var.py
    # and the payload-debug writer don't fail.
    foreach ($dir in @($Config.OutputDir, $Config.PayloadsDir)) {
        if (-not (Test-Path $dir)) {
            New-Item -ItemType Directory -Path $dir -Force | Out-Null
            Write-Host "  Created directory: $dir"
        }
    }

    # --- Generate the client-specific copy ---------------------------
    # update_sub_var.py reads Source_Path and Output_Path from env vars
    # (along with Client_Name, Subscription, Dashboard_Key) and writes
    # the customized JSON to Output_Path.
    Write-Host "Generating client-specific copy..."
    $env:Source_Path = $Config.HomepageTemplatePath
    $env:Output_Path = $Config.HomepageOutputPath

    python .\update_sub_var.py

    if ($LASTEXITCODE -ne 0) {
        throw "update_sub_var.py failed with exit code $LASTEXITCODE"
    }

    # --- Resolve the client's subfolder under Client-Homepages ------
    # The folder MUST already exist. We don't auto-create it here;
    # that's CreateFolder's job. SendDashboard is strictly upload.
    Write-Host "Resolving client folder under '$($Config.HomepageParentFolder)'..."

    # Find the parent folder (Client-Homepages)
    $encodedParent   = [uri]::EscapeDataString($Config.HomepageParentFolder)
    $parentSearchUri = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedParent"
    $parentResults   = Invoke-RestMethod -Method Get -Uri $parentSearchUri -Headers $headers
    $parentFolder    = $parentResults | Where-Object { $_.title -eq $Config.HomepageParentFolder }

    if ($null -eq $parentFolder) {
        throw "Parent folder '$($Config.HomepageParentFolder)' not found. Please create it first."
    }
    $parentFolderUid = @($parentFolder)[0].uid

    # Find the client's subfolder inside that parent
    $encodedClient   = [uri]::EscapeDataString($Config.HomepageFolderTitle)
    $clientSearchUri = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedClient&folderUIDs=$parentFolderUid"
    $clientResults   = Invoke-RestMethod -Method Get -Uri $clientSearchUri -Headers $headers
    $clientFolder    = $clientResults | Where-Object { $_.title -eq $Config.HomepageFolderTitle }

    if ($null -eq $clientFolder) {
        throw "Client folder '$($Config.HomepageFolderTitle)' not found under '$($Config.HomepageParentFolder)'. Run:  .\run.ps1 -Action CreateFolder  first."
    }

    $targetFolderUid = @($clientFolder)[0].uid
    $Config.HomepageFolderUid = $targetFolderUid
    Write-Host "  Client folder uid: $targetFolderUid"

    # --- Load the generated JSON and clean it for upload ------------
    Write-Host "Loading generated dashboard from: $($Config.HomepageOutputPath)"
    $dashboard = Get-Content -Raw -Path $Config.HomepageOutputPath | ConvertFrom-Json

    # Strip export-only fields that Grafana's UI export adds. Sending
    # them back through /api/dashboards/db causes a 400.
    foreach ($exportField in @('__inputs', '__elements', '__requires')) {
        if ($dashboard.PSObject.Properties.Name -contains $exportField) {
            $dashboard.PSObject.Properties.Remove($exportField)
        }
    }

    # Double-check homepage-safe values (the Python script does this,
    # but we defend against a hand-edited output file).
    $dashboard.id      = $null
    $dashboard.version = 0
    if ($dashboard.PSObject.Properties.Name -contains 'uid') {
        $dashboard.PSObject.Properties.Remove('uid')
    }

    # Title used for the existence check below
    $uploadTitle = $Config.DashboardTitle

} else {

    # ----------------------------------------------------------------
    # SHARED branch
    # ----------------------------------------------------------------
    Write-Host "Dashboard type: SHARED (golden template)"

    if (-not (Test-Path $Config.SharedTemplatePath)) {
        throw "Shared template not found: $($Config.SharedTemplatePath)"
    }

    # --- Resolve Shared / Client-Dashboards folder ------------------
    # Both the parent (Shared) and the child (Client-Dashboards) must
    # already exist in Grafana. We walk from the parent down.
    Write-Host "Resolving '$($Config.SharedParentFolder) / $($Config.SharedChildFolder)' folder..."

    # Parent: Shared
    $encodedSharedParent = [uri]::EscapeDataString($Config.SharedParentFolder)
    $sharedParentUri     = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedSharedParent"
    $sharedParentResults = Invoke-RestMethod -Method Get -Uri $sharedParentUri -Headers $headers
    $sharedParent        = $sharedParentResults | Where-Object { $_.title -eq $Config.SharedParentFolder }

    if ($null -eq $sharedParent) {
        throw "Parent folder '$($Config.SharedParentFolder)' not found in Grafana. Please create it first."
    }
    $sharedParentUid = @($sharedParent)[0].uid

    # Child: Client-Dashboards (inside Shared)
    $encodedSharedChild = [uri]::EscapeDataString($Config.SharedChildFolder)
    $sharedChildUri     = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedSharedChild&folderUIDs=$sharedParentUid"
    $sharedChildResults = Invoke-RestMethod -Method Get -Uri $sharedChildUri -Headers $headers
    $sharedChild        = $sharedChildResults | Where-Object { $_.title -eq $Config.SharedChildFolder }

    if ($null -eq $sharedChild) {
        throw "Child folder '$($Config.SharedChildFolder)' not found under '$($Config.SharedParentFolder)'. Please create it first."
    }

    $targetFolderUid = @($sharedChild)[0].uid
    $Config.SharedFolderUid = $targetFolderUid
    Write-Host "  Shared folder uid: $targetFolderUid"

    # --- Load the template JSON (no customization) ------------------
    Write-Host "Loading shared template from: $($Config.SharedTemplatePath)"
    $dashboard = Get-Content -Raw -Path $Config.SharedTemplatePath | ConvertFrom-Json

    # Strip export-only fields. Crucially, do NOT touch uid or id -
    # the UID is the stable identity that homepages link to.
    foreach ($exportField in @('__inputs', '__elements', '__requires')) {
        if ($dashboard.PSObject.Properties.Name -contains $exportField) {
            $dashboard.PSObject.Properties.Remove($exportField)
        }
    }

    # Shared title comes from the template itself
    $uploadTitle = $dashboard.title
    if ([string]::IsNullOrWhiteSpace($uploadTitle)) {
        throw "Shared template is missing a 'title' field: $($Config.SharedTemplatePath)"
    }
}


# ====================================================================
# Step 3 - Check for an existing dashboard in the target folder
# ====================================================================
# If one exists, prompt y/n before overwriting.

Write-Host "Checking for existing dashboard '$uploadTitle' in target folder..."

$encodedTitle  = [uri]::EscapeDataString($uploadTitle)
$searchDashUri = "$($Config.GrafanaUrl)/api/search?type=dash-db&query=$encodedTitle"
$searchResults = Invoke-RestMethod -Method Get -Uri $searchDashUri -Headers $headers

# Filter: exact title + type=dash-db + correct folder
$existingDashboard = $searchResults | Where-Object {
    $_.title     -eq $uploadTitle -and
    $_.type      -eq "dash-db" -and
    $_.folderUid -eq $targetFolderUid
}

$shouldOverwrite = $false
if ($null -ne $existingDashboard) {
    $answer = Read-Host "Dashboard '$uploadTitle' already exists in this folder. Overwrite? (y/n)"
    $answer = $answer.Trim().ToLower()

    if ($answer -ne "y" -and $answer -ne "yes") {
        Write-Host "Skipping upload (user declined overwrite)."
        return
    }
    $shouldOverwrite = $true
}


# ====================================================================
# Step 4 - Build the upload body
# ====================================================================
# POST /api/dashboards/db expects:
#   dashboard  - the full dashboard object
#   folderUid  - which folder to place the dashboard in
#   overwrite  - true if we're replacing an existing dashboard
#   message    - commit message visible in Grafana's version history
#
# -Depth 100 matters: the default depth of 2 would silently truncate
# the deeply nested panel/target/query structure inside a dashboard.

$uploadBodyObject = @{
    dashboard = $dashboard
    folderUid = $targetFolderUid
    overwrite = $shouldOverwrite
    message   = "Automated deployment via run.ps1 ($dashboardType)"
}

$uploadBody = $uploadBodyObject | ConvertTo-Json -Depth 100


# ====================================================================
# Step 5 - Save the payload for debugging, then upload
# ====================================================================
# Writing the exact request body to disk is cheap insurance. If
# Grafana rejects the upload, this file is invaluable for diagnosing.

if (-not [string]::IsNullOrWhiteSpace($Config.PayloadsDir)) {
    if (-not (Test-Path $Config.PayloadsDir)) {
        New-Item -ItemType Directory -Path $Config.PayloadsDir -Force | Out-Null
    }

    if (-not [string]::IsNullOrWhiteSpace($Config.PayloadFilePath)) {
        $uploadBody | Set-Content -Path $Config.PayloadFilePath -Encoding UTF8
        Write-Host "  Debug: saved payload to $($Config.PayloadFilePath)"
    }
}

# Use -ContentType on Invoke-RestMethod (instead of baking it into
# $headers) to avoid UTF-8 BOM issues that can trip up Grafana.
$uploadUri = "$($Config.GrafanaUrl)/api/dashboards/db"

try {
    $response = Invoke-RestMethod `
        -Method      Post `
        -Uri         $uploadUri `
        -Headers     $headers `
        -Body        $uploadBody `
        -ContentType "application/json; charset=utf-8"

    Write-Host ""
    Write-Host "Dashboard uploaded: $uploadTitle"
    if ($response.url) { Write-Host "  URL: $($Config.GrafanaUrl)$($response.url)" }
    if ($response.uid) { Write-Host "  UID: $($response.uid)" }
}
catch {
    Write-Host "Upload failed."

    # If we have an HTTP response, read it so the user sees why.
    if ($null -ne $_.Exception.Response) {
        $responseStream = $_.Exception.Response.GetResponseStream()
        $reader         = New-Object System.IO.StreamReader($responseStream)
        $responseBody   = $reader.ReadToEnd()

        Write-Host "  Status: $($_.Exception.Response.StatusCode)"
        Write-Host "  Body:   $responseBody"
    }

    if (-not [string]::IsNullOrWhiteSpace($Config.PayloadFilePath)) {
        Write-Host "  Payload saved at: $($Config.PayloadFilePath)"
    }

    throw
}
