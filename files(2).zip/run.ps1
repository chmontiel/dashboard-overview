# run.ps1
# =======
# Main entry point for Grafana client dashboard automation.
#
# This script is a DISPATCHER. It does not contain business logic
# itself. It:
#   1. Validates the -Action parameter
#   2. Loads environment variables from env.base.ps1
#   3. Applies any command-line overrides
#   4. Builds a config hashtable via config.ps1
#   5. Hands off to one of the five action scripts
#
# Each action script lives in its own file and implements its own
# rules. run.ps1 is only responsible for routing.
#
# USAGE:
#   .\run.ps1 -Action <action> [options]
#
# If -Action is missing or invalid, this script prints usage and
# exits cleanly WITHOUT touching Grafana.


param(
    # The action to run. Must be one of:
    #   CreateFolder, SendDashboard, Onboard, DeleteDashboard, DeleteFolder
    [string]$Action,

    # --- Optional overrides ------------------------------------------
    # These take precedence over values set in env.base.ps1.
    # They save you from editing env.base.ps1 for one-off runs.

    # Single-dashboard key for SendDashboard / DeleteDashboard.
    # Example: -DashboardKey home
    [string]$DashboardKey,

    # Dashboard type for SendDashboard. Must be "homepage" or "shared".
    # Example: -DashboardType shared
    [string]$DashboardType,

    # List of dashboard keys for Onboard (homepage dashboards to send
    # after creating the folder).
    # Example: -DashboardKeys home,overview
    [string[]]$DashboardKeys
)

# Stop on the first error rather than silently continuing.
$ErrorActionPreference = "Stop"

# Ensure relative paths (.\config.ps1 etc.) resolve against THIS
# script's directory, not whatever directory the user happened to
# be in when they ran it.
Set-Location $PSScriptRoot


# ====================================================================
# Usage banner
# ====================================================================
# Printed when -Action is missing or invalid. Also printed on demand
# if you want to see the available actions and their requirements.

function Show-Usage {
    Write-Host ""
    Write-Host "Grafana client dashboard automation"
    Write-Host "-----------------------------------"
    Write-Host ""
    Write-Host "USAGE:"
    Write-Host "  .\run.ps1 -Action <action> [options]"
    Write-Host ""
    Write-Host "ACTIONS:"
    Write-Host ""
    Write-Host "  CreateFolder"
    Write-Host "    Create a client subfolder inside Client-Homepages."
    Write-Host "    Required env: Grafana_Url, Token, Client_Name"
    Write-Host ""
    Write-Host "  SendDashboard"
    Write-Host "    Upload ONE dashboard to Grafana."
    Write-Host "    Required env: Grafana_Url, Token, Client_Name,"
    Write-Host "                  Dashboards_Dir, Dashboard_Key, Dashboard_Type"
    Write-Host "    Homepage type also requires: Subscription"
    Write-Host "    Override flags: -DashboardKey, -DashboardType"
    Write-Host ""
    Write-Host "  Onboard"
    Write-Host "    Create the client folder and send multiple homepage dashboards."
    Write-Host "    Required env: (same as SendDashboard for homepage type)"
    Write-Host "    Override flag: -DashboardKeys key1,key2,..."
    Write-Host ""
    Write-Host "  DeleteDashboard"
    Write-Host "    Delete one dashboard. Prompts for confirmation."
    Write-Host "    Required env: Grafana_Url, Token, Client_Name, Dashboard_Key"
    Write-Host "    Override flag: -DashboardKey"
    Write-Host ""
    Write-Host "  DeleteFolder"
    Write-Host "    Delete a client folder and its dashboards. Prompts for confirmation."
    Write-Host "    Required env: Grafana_Url, Token, Client_Name"
    Write-Host ""
    Write-Host "EXAMPLES:"
    Write-Host "  .\run.ps1 -Action CreateFolder"
    Write-Host "  .\run.ps1 -Action SendDashboard -DashboardKey home -DashboardType homepage"
    Write-Host "  .\run.ps1 -Action SendDashboard -DashboardKey infrastructure -DashboardType shared"
    Write-Host "  .\run.ps1 -Action Onboard -DashboardKeys home,overview"
    Write-Host "  .\run.ps1 -Action DeleteDashboard -DashboardKey home"
    Write-Host "  .\run.ps1 -Action DeleteFolder"
    Write-Host ""
    Write-Host "Edit env.base.ps1 to set environment variables."
    Write-Host ""
}


# ====================================================================
# Step 1 - Validate -Action
# ====================================================================
# If no action was given or the value doesn't match one we know, we
# print usage and exit cleanly. No env loading, no API calls, nothing.

$validActions = @(
    "CreateFolder",
    "SendDashboard",
    "Onboard",
    "DeleteDashboard",
    "DeleteFolder"
)

if ([string]::IsNullOrWhiteSpace($Action)) {
    # User ran `.\run.ps1` with no arguments. Show usage and stop.
    Show-Usage
    return
}

if ($validActions -notcontains $Action) {
    # User passed something like `-Action Foo`. Tell them and stop.
    Write-Host ""
    Write-Host "ERROR: '$Action' is not a valid action."
    Show-Usage
    return
}


# ====================================================================
# Step 2 - Load environment variables
# ====================================================================
# Dot-sourcing (the leading ".") runs env.base.ps1 in THIS script's
# scope. That's what allows the $env:... assignments inside it to
# persist for the rest of this run.

Write-Host ""
Write-Host "==== Grafana automation : $Action ===="
Write-Host ""
Write-Host "Loading environment variables from env.base.ps1..."
. .\env.base.ps1


# ====================================================================
# Step 3 - Apply command-line overrides
# ====================================================================
# If the user passed -DashboardKey or -DashboardType on the command
# line, overwrite the corresponding $env: value. This lets you
# switch dashboards/types per run without editing env.base.ps1.

if (-not [string]::IsNullOrWhiteSpace($DashboardKey)) {
    $env:Dashboard_Key = $DashboardKey.Trim().ToLower()
    Write-Host "  Override applied: Dashboard_Key = $env:Dashboard_Key"
}

if (-not [string]::IsNullOrWhiteSpace($DashboardType)) {
    $env:Dashboard_Type = $DashboardType.Trim().ToLower()
    Write-Host "  Override applied: Dashboard_Type = $env:Dashboard_Type"
}


# ====================================================================
# Step 4 - Build config
# ====================================================================
# config.ps1 reads $env:... values and returns a hashtable. That
# hashtable is the single source of settings each action script
# uses (passed in via the -Config parameter).
#
# config.ps1 will THROW if a required env var (Grafana_Url, Token,
# Client_Name) is missing. That's the correct behavior - we want
# to fail loudly rather than silently run with bad settings.

Write-Host "Building config..."
$config = . .\config.ps1

Write-Host "  Client:       $($config.ClientName)"
Write-Host "  Grafana URL:  $($config.GrafanaUrl)"


# ====================================================================
# Step 5 - Dispatch to the chosen action script
# ====================================================================
# Each branch dot-sources the matching action script and passes it
# the config hashtable. The action script is responsible for its
# own validation (e.g. SendDashboard checks that Dashboard_Key and
# Dashboard_Type are set).

Write-Host "Dispatching: $Action"
Write-Host ""

switch ($Action) {
    "CreateFolder" {
        . .\create-folder.ps1 -Config $config
    }
    "SendDashboard" {
        . .\send-dashboard.ps1 -Config $config
    }
    "Onboard" {
        . .\onboard.ps1 -Config $config -DashboardKeys $DashboardKeys
    }
    "DeleteDashboard" {
        . .\delete-dashboard.ps1 -Config $config
    }
    "DeleteFolder" {
        . .\delete-folder.ps1 -Config $config
    }
}

Write-Host ""
Write-Host "==== Done ===="
Write-Host ""
