# delete-folder.ps1
# =================
# Deletes a client folder from Grafana along with all its dashboards.
#
# STEPS:
#   1. Find the client's folder by name (under Client-Homepages).
#      If it doesn't exist, exit cleanly - nothing to do.
#   2. List the dashboards inside that folder so the user can see
#      exactly what's going away.
#   3. Show a preview (folder name + child count + titles).
#   4. Prompt for confirmation. Keep prompting until valid y/n.
#   5. If confirmed:
#        a. Delete each child dashboard first
#        b. Then delete the folder itself
#      If denied, cancel cleanly.
#
# WHY DELETE CHILDREN BEFORE THE FOLDER:
#   Grafana normally deletes children with the folder, but doing it
#   explicitly means we get per-dashboard success/failure logging,
#   and avoids any "folder not empty" edge cases.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"


# ====================================================================
# HTTP headers
# ====================================================================
$grafanaBase = $Config.GrafanaUrl.TrimEnd('/')

$headers = @{
    Authorization  = "Bearer $($Config.Token)"
    "Content-Type" = "application/json"
}


# ====================================================================
# Step 1 - Find the client folder
# ====================================================================
# Using the k8s-style folders endpoint (same style as the dashboards
# API). We iterate the full list and match on spec.title.

$clientFolderName = $Config.HomepageFolderTitle   # same as ClientName

Write-Host "Looking up folder: '$clientFolderName'..."

$foldersListUri  = "$grafanaBase/apis/folder.grafana.app/v1beta1/namespaces/default/folders"
$foldersResponse = Invoke-RestMethod -Method Get -Uri $foldersListUri -Headers $headers

$folderUid   = ""
$folderTitle = ""

foreach ($folder in $foldersResponse.items) {
    if ($folder.spec.title -eq $clientFolderName) {
        $folderUid   = $folder.metadata.name
        $folderTitle = $folder.spec.title
        break
    }
}

if ([string]::IsNullOrWhiteSpace($folderUid)) {
    Write-Host "Folder '$clientFolderName' not found in Grafana. Nothing to delete."
    return
}

Write-Host "  Found folder:"
Write-Host "    Title: $folderTitle"
Write-Host "    UID:   $folderUid"


# ====================================================================
# Step 2 - List the dashboards inside the folder
# ====================================================================
# /api/search with folderUIDs limits results to just our folder.
# type=dash-db ensures we only get dashboards, not nested folders.

Write-Host ""
Write-Host "Listing dashboards in folder..."

$searchUri     = "$grafanaBase/api/search?type=dash-db&folderUIDs=$folderUid"
$searchHeaders = @{
    Authorization = "Bearer $($Config.Token)"
    Accept        = "application/json"
}

$childDashboards = Invoke-RestMethod -Method Get -Uri $searchUri -Headers $searchHeaders

# Normalize to an array. When there's zero or one result, PowerShell
# can give us $null or a single object instead of an array, which
# breaks .Count and foreach. @() forces array shape.
$childDashboards = @($childDashboards)
$childCount      = $childDashboards.Count


# ====================================================================
# Step 3 - Show the preview
# ====================================================================

Write-Host ""
Write-Host "About to delete:"
Write-Host "  Folder:     $folderTitle (uid: $folderUid)"
Write-Host "  Dashboards: $childCount"

if ($childCount -gt 0) {
    foreach ($child in $childDashboards) {
        Write-Host "    - $($child.title)  (uid: $($child.uid))"
    }
}
Write-Host ""


# ====================================================================
# Step 4 - Prompt for confirmation (loops on invalid input)
# ====================================================================

$confirmed = $false

do {
    $answer = (Read-Host "Are you sure you want to delete this folder and all its dashboards? (y/n)").Trim()

    if ($answer -match '^(?i)(y|yes)$') {
        $confirmed  = $true
        $validInput = $true
    }
    elseif ($answer -match '^(?i)(n|no)$') {
        $confirmed  = $false
        $validInput = $true
    }
    else {
        Write-Host "  Invalid input. Please enter y, yes, n, or no."
        $validInput = $false
    }
} until ($validInput)

if (-not $confirmed) {
    Write-Host "Delete cancelled by user. Folder was not touched."
    return
}


# ====================================================================
# Step 5a - Delete child dashboards first
# ====================================================================
# We delete dashboards one at a time so we can log each result.
# If one fails, the loop stops and the folder is left in place -
# user can inspect what went wrong and rerun.

if ($childCount -gt 0) {
    Write-Host ""
    Write-Host "Deleting $childCount dashboard(s)..."

    $currentIndex = 0
    foreach ($child in $childDashboards) {
        $currentIndex++

        $childUid   = $child.uid
        $childTitle = $child.title
        $childUri   = "$grafanaBase/apis/dashboard.grafana.app/v1beta1/namespaces/default/dashboards/$childUid"

        Write-Host "  [$currentIndex/$childCount] Deleting '$childTitle' (uid: $childUid)..."

        try {
            Invoke-RestMethod -Method Delete -Uri $childUri -Headers $headers | Out-Null
            Write-Host "    OK"
        }
        catch {
            Write-Host "    FAILED: $($_.Exception.Message)"
            Write-Host "Stopping. Folder was NOT deleted. Fix the error above and rerun."
            throw
        }
    }
}


# ====================================================================
# Step 5b - Delete the folder itself
# ====================================================================

Write-Host ""
Write-Host "Deleting folder '$folderTitle'..."

$folderDeleteUri = "$grafanaBase/apis/folder.grafana.app/v1beta1/namespaces/default/folders/$folderUid"

Invoke-RestMethod -Method Delete -Uri $folderDeleteUri -Headers $headers | Out-Null

Write-Host "  Deleted successfully."
