# onboard.ps1
# ===========
# Full onboarding workflow for a new client subscription.
#
# WHAT IT DOES:
#   1. Creates the client's subfolder under Client-Homepages
#      (by calling create-folder.ps1)
#   2. For each dashboard key the user passed in, uploads that
#      homepage dashboard into the new folder
#      (by calling send-dashboard.ps1 with DashboardType = homepage)
#
# WHY HOMEPAGE ONLY:
#   Shared dashboards are the "golden set" - they get deployed ONCE
#   globally to Shared/Client-Dashboards and are reused by every
#   client. They are NOT deployed per client, so we don't send them
#   as part of onboarding. Homepage dashboards link to them instead.
#
# FAIL-FAST RULE:
#   If CreateFolder fails, we do NOT proceed to the SendDashboard
#   loop. If any single dashboard upload fails mid-loop, we stop
#   there and report which one failed.
#
# EXAMPLE:
#   .\run.ps1 -Action Onboard -DashboardKeys home,overview
#
#   Produces:
#     Client-Homepages /
#       Acme Corp /
#         Acme Corp-Home
#         Acme Corp-Overview

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config,

    # List of dashboard keys (homepage templates) to upload.
    # Passed through from run.ps1's -DashboardKeys parameter.
    # Example: @("home", "overview")
    [string[]]$DashboardKeys
)

$ErrorActionPreference = "Stop"


# ====================================================================
# Step 1 - Validate the dashboard keys list
# ====================================================================
# Onboard is pointless without at least one dashboard to deploy, so
# we refuse to run if the list is empty.
#
# If -DashboardKeys wasn't passed, we fall back to $env:Dashboard_Key
# as a convenience (lets you onboard a single dashboard without the
# array syntax).

if ($null -eq $DashboardKeys -or $DashboardKeys.Count -eq 0) {
    if (-not [string]::IsNullOrWhiteSpace($env:Dashboard_Key)) {
        $DashboardKeys = @($env:Dashboard_Key)
        Write-Host "No -DashboardKeys passed; using Dashboard_Key from env: $($env:Dashboard_Key)"
    } else {
        throw "No dashboards specified. Pass -DashboardKeys key1,key2 or set Dashboard_Key in env.base.ps1."
    }
}


# ====================================================================
# Step 2 - Validate shared pre-requisites ONCE
# ====================================================================
# Every dashboard in the loop needs the same baseline values. Rather
# than let send-dashboard.ps1 fail halfway through, check them here
# before we touch Grafana at all.

if ([string]::IsNullOrWhiteSpace($Config.SubscriptionId)) {
    throw "Subscription is missing. Required for homepage dashboards."
}
if ([string]::IsNullOrWhiteSpace($Config.DashboardsDir)) {
    throw "Dashboards_Dir is missing. Set it in env.base.ps1."
}

# Print the onboarding plan so the user sees what's about to happen
# before any folders or dashboards are created.
Write-Host ""
Write-Host "Onboarding plan"
Write-Host "---------------"
Write-Host "  Client:        $($Config.ClientName)"
Write-Host "  Subscription:  $($Config.SubscriptionId)"
Write-Host "  Folder:        $($Config.HomepageParentFolder) / $($Config.HomepageFolderTitle)"
Write-Host "  Dashboards:    $($DashboardKeys -join ', ')"
Write-Host ""


# ====================================================================
# Step 3 - Create the client folder
# ====================================================================
# Calls create-folder.ps1 with our config. On success that script
# writes the folder UID back into $Config.HomepageFolderUid so the
# SendDashboard calls can skip their own folder lookup.
#
# If this step fails, the "Stop" error preference bubbles the error
# up and we never reach the dashboard loop.

Write-Host "[1/2] Creating client folder..."
Write-Host ""

. .\create-folder.ps1 -Config $Config

Write-Host ""


# ====================================================================
# Step 4 - Upload each homepage dashboard
# ====================================================================
# Loop through the keys and call send-dashboard.ps1 once per key.
# Before each call we update the config + env var for the specific
# dashboard, because send-dashboard.ps1 reads these to decide which
# template to load and what title to use.
#
# Why update BOTH $Config fields AND $env: values?
#   - send-dashboard.ps1 reads from $Config
#   - update_sub_var.py (called by send-dashboard for homepage type)
#     reads from $env: environment variables
#   - They need to agree, so we set both.

$totalDashboards = $DashboardKeys.Count
$currentIndex    = 0

foreach ($rawKey in $DashboardKeys) {
    $currentIndex++

    # Normalize the key: trim whitespace and lowercase. This matches
    # how config.ps1 normalizes Dashboard_Key from env.
    $dashboardKey = $rawKey.Trim().ToLower()

    if ([string]::IsNullOrWhiteSpace($dashboardKey)) {
        Write-Host "  [skip] Empty dashboard key at position $currentIndex"
        continue
    }

    # Derive the capitalized label (matches config.ps1 logic).
    # "home" -> "Home",  "overview" -> "Overview"
    if ($dashboardKey.Length -gt 1) {
        $dashboardLabel = $dashboardKey.Substring(0, 1).ToUpper() + $dashboardKey.Substring(1)
    } else {
        $dashboardLabel = $dashboardKey.ToUpper()
    }

    Write-Host "[2/2] Uploading dashboard $currentIndex of ${totalDashboards}: $dashboardKey"
    Write-Host ""

    # -- Update the config for this specific dashboard ---------------
    # These are the only fields that change per dashboard within one
    # onboarding run. Everything else (folder, client, subscription,
    # paths) stays the same.
    $Config.DashboardKey          = $dashboardKey
    $Config.DashboardLabel        = $dashboardLabel
    $Config.DashboardType         = "homepage"
    $Config.DashboardTitle        = "$($Config.ClientName)-$dashboardLabel"
    $Config.DashboardDescription  = "$($Config.ClientName)-$dashboardLabel"

    # Rebuild the dashboard-specific file paths
    $Config.HomepageTemplatePath = Join-Path `
        (Join-Path $Config.TemplatesDir "client") `
        "Client-$dashboardLabel.json"
    $Config.HomepageOutputPath = Join-Path `
        $Config.OutputDir `
        "$($Config.SafeName)-$dashboardKey.json"
    $Config.PayloadFilePath = Join-Path `
        $Config.PayloadsDir `
        "$($Config.SafeName)-$dashboardKey-submit-body.json"

    # -- Update env vars for update_sub_var.py -----------------------
    $env:Dashboard_Key = $dashboardKey

    # -- Actually send the dashboard ---------------------------------
    # If this call throws, the loop stops and onboarding reports the
    # specific dashboard that failed.
    try {
        . .\send-dashboard.ps1 -Config $Config
    }
    catch {
        Write-Host ""
        Write-Host "Onboarding stopped: dashboard '$dashboardKey' failed to upload."
        Write-Host "  Error: $($_.Exception.Message)"
        throw
    }

    Write-Host ""
}


# ====================================================================
# Step 5 - Summary
# ====================================================================
Write-Host "Onboarding complete for '$($Config.ClientName)'."
Write-Host "  Folder:     $($Config.HomepageParentFolder) / $($Config.HomepageFolderTitle)"
Write-Host "  Uploaded:   $($DashboardKeys -join ', ')"
