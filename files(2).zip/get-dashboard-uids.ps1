# get-dashboard-uids.ps1
# ======================
# Helper script for the delete flow. Looks up a dashboard by title
# and returns its UID along with a few other details.
#
# HOW IT WORKS:
#   Calls Grafana's k8s-style dashboard API and iterates the returned
#   items looking for a title that matches the naming convention:
#     "{Client_Name}-{Dashboard_Key_Label}"
#
#   Examples of titles it matches:
#     Client_Name="Acme Corp", Dashboard_Key="home"     -> "Acme Corp-Home"
#     Client_Name="Acme Corp", Dashboard_Key="overview" -> "Acme Corp-Overview"
#
# OUTPUT:
#   Returns a PSCustomObject with fields:
#     uid   - the dashboard UID (empty string if not found)
#     title - the exact title Grafana has on record (empty if not found)
#
#   delete-dashboard.ps1 captures this via:
#     $result = .\get-dashboard-uids.ps1 -Config $Config
#
# NOTE: This script only looks up HOMEPAGE dashboards (titled with the
# client name prefix). Shared dashboards live in a different folder
# and have different titles - they shouldn't be deleted per-client.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"


# ====================================================================
# Step 1 - Validate the inputs we need
# ====================================================================
if ([string]::IsNullOrWhiteSpace($Config.DashboardKey)) {
    throw "Dashboard_Key is missing. Set it in env.base.ps1 or pass -DashboardKey."
}


# ====================================================================
# Step 2 - Build the expected dashboard title
# ====================================================================
# Matches the title format used when homepage dashboards are uploaded:
#   "{ClientName}-{DashboardLabel}"
# DashboardTitle was already computed by config.ps1.

$expectedTitle = $Config.DashboardTitle

Write-Host "Looking up dashboard by title: '$expectedTitle'"


# ====================================================================
# Step 3 - Call the Grafana dashboards API
# ====================================================================
# Using the k8s-style endpoint (apis/dashboard.grafana.app/...) because
# it returns the UID via metadata.name which is stable and lets us
# build a direct DELETE URL later.
#
# TrimEnd('/') prevents double-slash if someone included a trailing
# slash in $env:Grafana_Url.

$grafanaBase = $Config.GrafanaUrl.TrimEnd('/')

$headers = @{
    Authorization  = "Bearer $($Config.Token)"
    "Content-Type" = "application/json"
}

$listUri = "$grafanaBase/apis/dashboard.grafana.app/v1beta1/namespaces/default/dashboards"

$response = Invoke-RestMethod -Method Get -Uri $listUri -Headers $headers


# ====================================================================
# Step 4 - Iterate the items looking for an exact title match
# ====================================================================
# Start with empty defaults so the return shape is consistent whether
# we find the dashboard or not.

$foundUid   = ""
$foundTitle = ""

foreach ($dashboard in $response.items) {
    # Each item has spec.title (display name) and metadata.name (UID)
    $currentTitle = $dashboard.spec.title

    if ($currentTitle -eq $expectedTitle) {
        $foundUid   = $dashboard.metadata.name
        $foundTitle = $currentTitle

        Write-Host "  Found dashboard:"
        Write-Host "    Title: $foundTitle"
        Write-Host "    UID:   $foundUid"
        break
    }
}

if ([string]::IsNullOrWhiteSpace($foundUid)) {
    Write-Host "  No dashboard found with title '$expectedTitle'"
}


# ====================================================================
# Step 5 - Return a structured result
# ====================================================================
# [pscustomobject] gives a typed object the caller can access with
# $result.uid and $result.title. Cleaner than returning a hashtable.

[pscustomobject]@{
    uid   = $foundUid
    title = $foundTitle
}
