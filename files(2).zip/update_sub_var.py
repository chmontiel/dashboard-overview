"""
update_sub_var.py
-----------------
Creates a client-specific copy of a HOMEPAGE dashboard template.

This script is ONLY used for homepage (client-specific) dashboards.
Shared dashboards preserve their template UID and variables exactly
as-is, so they skip this script entirely.

WHAT IT DOES:
  Reads the template at Source_Path, applies client-specific changes,
  and writes the result to Output_Path. The original template file
  is NEVER modified.

CHANGES APPLIED TO THE JSON:
  1. title       -> "{ClientName}-{DashboardLabel}"
  2. description -> "{ClientName}-{DashboardLabel}"
  3. uid         -> removed entirely (Grafana assigns a fresh one)
  4. id          -> null  (tells the API this is a new dashboard)
  5. version     -> 0     (reset version counter)
  6. Template variable 'sub' (Azure subscription selector):
        current.text   -> client name
        current.value  -> subscription ID
        hide           -> 2  (fully hidden; user cannot change it)
        query.subscription -> subscription ID
        query.grafanaTemplateVariableFn.subscription -> subscription ID

REQUIRED ENVIRONMENT VARIABLES:
  Client_Name     Display name of the client (e.g. "Acme Corp")
  Subscription    Azure subscription ID
  Dashboard_Key   Dashboard key (e.g. "home", "overview")
  Source_Path     Full path to the source template JSON
  Output_Path     Full path where the customized JSON will be written

USAGE:
  send-dashboard.ps1 sets the env vars and calls this script. You
  shouldn't normally need to run it directly.
"""

import json
import os
import sys


# ---------------------------------------------------------------------
# Read and validate required environment variables
# ---------------------------------------------------------------------
CLIENT_NAME     = os.environ.get("Client_Name", "").strip()
SUBSCRIPTION_ID = os.environ.get("Subscription", "").strip()
DASHBOARD_KEY   = os.environ.get("Dashboard_Key", "").strip().lower()
SOURCE_PATH     = os.environ.get("Source_Path", "").strip()
OUTPUT_PATH     = os.environ.get("Output_Path", "").strip()

missing = []
if not CLIENT_NAME:     missing.append("Client_Name")
if not SUBSCRIPTION_ID: missing.append("Subscription")
if not DASHBOARD_KEY:   missing.append("Dashboard_Key")
if not SOURCE_PATH:     missing.append("Source_Path")
if not OUTPUT_PATH:     missing.append("Output_Path")

if missing:
    print(f"ERROR: Missing environment variables: {', '.join(missing)}")
    sys.exit(1)


# ---------------------------------------------------------------------
# Derive display values
# ---------------------------------------------------------------------
# "home" -> "Home",  "overview" -> "Overview"
if len(DASHBOARD_KEY) > 1:
    DASHBOARD_LABEL = DASHBOARD_KEY[:1].upper() + DASHBOARD_KEY[1:]
else:
    DASHBOARD_LABEL = DASHBOARD_KEY.upper()

DASHBOARD_TITLE       = f"{CLIENT_NAME}-{DASHBOARD_LABEL}"
DASHBOARD_DESCRIPTION = f"{CLIENT_NAME}-{DASHBOARD_LABEL}"

# Visibility of the subscription dropdown in Grafana:
#   0 = visible, 1 = label only, 2 = fully hidden
HIDE_SUB_VARIABLE = 2


# ---------------------------------------------------------------------
# Helper functions
# ---------------------------------------------------------------------
def load_template(path: str) -> dict:
    """Read the template JSON from disk into a Python dict."""
    if not os.path.isfile(path):
        print(f"ERROR: Template not found: {path}")
        sys.exit(1)

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def apply_metadata_changes(dashboard: dict) -> None:
    """
    Update the top-level fields. Mutates the dict in place.

      title       -> "{ClientName}-{DashboardLabel}"
      description -> "{ClientName}-{DashboardLabel}"
      id          -> None  (null in JSON; tells Grafana "new dashboard")
      version     -> 0
      uid         -> removed entirely (Grafana will assign a new one)
    """
    dashboard["title"]       = DASHBOARD_TITLE
    dashboard["description"] = DASHBOARD_DESCRIPTION
    dashboard["id"]          = None
    dashboard["version"]     = 0
    dashboard.pop("uid", None)  # pop with default = no KeyError if absent


def update_subscription_variable(dashboard: dict) -> None:
    """
    Find the template variable named 'sub' and point it at this
    client's Azure subscription. Mutates the dict in place.

    Sets:
      current.text       = client name (what Grafana displays)
      current.value      = subscription ID (value used in queries)
      hide               = 2 (hidden; user cannot switch subscriptions)
      query.subscription = subscription ID (locks data source to this sub)
      query.grafanaTemplateVariableFn.subscription = same (nested hook)
    """
    template_list = dashboard.get("templating", {}).get("list", [])

    # Locate the variable named "sub" inside the templating list
    sub_var = None
    for var in template_list:
        if var.get("name") == "sub":
            sub_var = var
            break

    if sub_var is None:
        print("ERROR: Could not find template variable 'sub' in the dashboard JSON.")
        sys.exit(1)

    # What Grafana displays as the selected value on dashboard load
    sub_var["current"] = {
        "text":  CLIENT_NAME,
        "value": SUBSCRIPTION_ID,
    }

    # Fully hide the dropdown
    sub_var["hide"] = HIDE_SUB_VARIABLE

    # Update the query block so the variable is locked to this subscription
    query = sub_var.get("query")
    if isinstance(query, dict):
        query["subscription"] = SUBSCRIPTION_ID

        # Some templates also carry a nested grafanaTemplateVariableFn
        # with its own subscription field. Update it if present.
        fn = query.get("grafanaTemplateVariableFn")
        if isinstance(fn, dict) and "subscription" in fn:
            fn["subscription"] = SUBSCRIPTION_ID


def save_dashboard(dashboard: dict, path: str) -> None:
    """Write the modified dashboard JSON to disk, creating dirs if needed."""
    output_dir = os.path.dirname(path)
    if output_dir and not os.path.isdir(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(dashboard, f, indent=2, ensure_ascii=False)


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------
def main():
    print(f"Loading template: {SOURCE_PATH}")
    dashboard = load_template(SOURCE_PATH)

    apply_metadata_changes(dashboard)
    update_subscription_variable(dashboard)

    save_dashboard(dashboard, OUTPUT_PATH)

    print("Client dashboard copy created:")
    print(f"  Title:         {DASHBOARD_TITLE}")
    print(f"  Subscription:  {CLIENT_NAME} ({SUBSCRIPTION_ID})")
    print(f"  Hidden:        yes (hide={HIDE_SUB_VARIABLE})")
    print(f"  Output:        {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
