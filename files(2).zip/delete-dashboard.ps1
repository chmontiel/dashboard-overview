# delete-dashboard.ps1
# ====================
# Deletes ONE dashboard from Grafana after user confirmation.
#
# STEPS:
#   1. Call get-dashboard-uids.ps1 to find the dashboard's UID
#      using the client name + dashboard key.
#   2. Verify the dashboard actually exists by doing a GET to
#      confirm the UID is valid and grab the current title.
#   3. Show the user what's about to be deleted (title + UID).
#   4. Prompt for confirmation. Keep prompting until a valid
#      y/yes or n/no answer is given.
#   5. If confirmed, DELETE. If denied, cancel cleanly.
#
# WHY WE LOOK UP THE TITLE FROM GRAFANA INSTEAD OF ENV:
#   The env var gives us the EXPECTED title. Grafana gives us the
#   ACTUAL title. Showing Grafana's truth in the preview means the
#   user can spot "wait, that's not the dashboard I meant" before
#   typing yes.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

$ErrorActionPreference = "Stop"


# ====================================================================
# Step 1 - Find the dashboard UID
# ====================================================================
# get-dashboard-uids.ps1 returns a PSCustomObject with uid + title.
# If it didn't find one, uid will be an empty string.

$lookup = .\get-dashboard-uids.ps1 -Config $Config
$dashboardUid   = $lookup.uid
$lookupTitle    = $lookup.title

if ([string]::IsNullOrWhiteSpace($dashboardUid)) {
    Write-Host ""
    Write-Host "No matching dashboard found. Nothing to delete."
    return
}


# ====================================================================
# Step 2 - Build the DELETE URL from the UID Grafana returned
# ====================================================================
# Important: we build this URL from the UID the API just gave us, NOT
# from any env var. Means we can never delete a different dashboard
# than the one we just looked up.

$grafanaBase = $Config.GrafanaUrl.TrimEnd('/')
$dashboardUri = "$grafanaBase/apis/dashboard.grafana.app/v1beta1/namespaces/default/dashboards/$dashboardUid"

$headers = @{
    Authorization  = "Bearer $($Config.Token)"
    "Content-Type" = "application/json"
}


# ====================================================================
# Step 3 - Verify the dashboard still exists and get its current title
# ====================================================================
# Double-check with a GET before showing the preview. If something
# deleted the dashboard between our lookup and now, we catch it here.

Write-Host ""
Write-Host "Verifying dashboard in Grafana..."

try {
    $dashboardDetails = Invoke-RestMethod -Method Get -Uri $dashboardUri -Headers $headers
}
catch {
    Write-Host "Dashboard with UID '$dashboardUid' no longer exists. Nothing to delete."
    return
}

$currentTitle = $dashboardDetails.spec.title


# ====================================================================
# Step 4 - Show the preview
# ====================================================================
# This is what the user is confirming. Both title and UID come from
# Grafana's response (not env vars), so the user sees ground truth.

Write-Host ""
Write-Host "About to delete:"
Write-Host "  Title: $currentTitle"
Write-Host "  UID:   $dashboardUid"
Write-Host ""


# ====================================================================
# Step 5 - Prompt for confirmation (loops on invalid input)
# ====================================================================
# The do/until block keeps prompting until we get a valid answer.
# -match with '(?i)' makes the regex case-insensitive, so Y, y, YES,
# yes, Yes all work.

$confirmed = $false

do {
    $answer = (Read-Host "Are you sure you want to delete this dashboard? (y/n)").Trim()

    if ($answer -match '^(?i)(y|yes)$') {
        $confirmed  = $true
        $validInput = $true
    }
    elseif ($answer -match '^(?i)(n|no)$') {
        $confirmed  = $false
        $validInput = $true
    }
    else {
        Write-Host "  Invalid input. Please enter y, yes, n, or no."
        $validInput = $false
    }
} until ($validInput)


# ====================================================================
# Step 6 - Act on the answer
# ====================================================================

if (-not $confirmed) {
    Write-Host "Delete cancelled by user. Dashboard was not touched."
    return
}

Write-Host ""
Write-Host "Deleting dashboard '$currentTitle'..."

Invoke-RestMethod -Method Delete -Uri $dashboardUri -Headers $headers | Out-Null

Write-Host "  Deleted successfully."
