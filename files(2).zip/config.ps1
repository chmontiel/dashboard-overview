# config.ps1
# ==========
# Reads environment variables and returns a config hashtable used by
# every other script.
#
# WHY THIS FILE EXISTS:
#   Rather than sprinkle $env:... lookups across every script, we
#   centralize them here. Each action script receives the hashtable
#   as a parameter, which keeps those scripts decoupled from the
#   environment.
#
# WHAT IT VALIDATES:
#   Only the three values needed to build a usable config hashtable:
#     - Grafana_Url
#     - Token
#     - Client_Name
#
#   Action-specific requirements (e.g. "Dashboard_Key is needed for
#   SendDashboard") are checked by each action script, NOT here.
#
# HOW IT'S CALLED:
#   $config = . .\config.ps1
#
#   The "." (dot-source) operator runs the script in the current
#   scope. The last expression in this file is a hashtable, so that
#   hashtable becomes the return value.


# ====================================================================
# Section 1 - Read and validate the minimum required env vars
# ====================================================================
$grafanaUrl = $env:Grafana_Url
$token      = $env:Token
$clientName = $env:Client_Name

if ([string]::IsNullOrWhiteSpace($grafanaUrl)) {
    throw "Grafana_Url is missing. Set it in env.base.ps1."
}
if ([string]::IsNullOrWhiteSpace($token)) {
    throw "Token is missing. Set it in env.base.ps1."
}
if ([string]::IsNullOrWhiteSpace($clientName)) {
    throw "Client_Name is missing. Set it in env.base.ps1."
}


# ====================================================================
# Section 2 - Read the optional env vars
# ====================================================================
# These may be empty. Action scripts that need them will check.
# We lowercase dashboard key and type up front so comparisons
# elsewhere are case-insensitive.

$subscriptionId = $env:Subscription
$dashboardsDir  = $env:Dashboards_Dir

$dashboardKey = if ([string]::IsNullOrWhiteSpace($env:Dashboard_Key)) {
    ""
} else {
    $env:Dashboard_Key.Trim().ToLower()
}

$dashboardType = if ([string]::IsNullOrWhiteSpace($env:Dashboard_Type)) {
    ""
} else {
    $env:Dashboard_Type.Trim().ToLower()
}


# ====================================================================
# Section 3 - Derive helper values
# ====================================================================

# safeName: URL and filename-safe version of the client name.
# Examples:
#   "Acme Corp"  -> "acme-corp"
#   "Foo & Bar"  -> "foo-bar"
$safeName = $clientName.ToLower().Trim() -replace '[^a-z0-9]+', '-'
$safeName = $safeName.Trim('-')

# dashboardLabel: capitalized version of the dashboard key.
# Used in template filenames and dashboard display titles.
# Examples:
#   "home"     -> "Home"
#   "overview" -> "Overview"
# If dashboardKey is empty, dashboardLabel is empty too.
if ($dashboardKey.Length -gt 1) {
    $dashboardLabel = $dashboardKey.Substring(0, 1).ToUpper() + $dashboardKey.Substring(1)
} elseif ($dashboardKey.Length -eq 1) {
    $dashboardLabel = $dashboardKey.ToUpper()
} else {
    $dashboardLabel = ""
}


# ====================================================================
# Section 4 - Build template and output paths
# ====================================================================
# These are only valid if Dashboards_Dir was set. If it wasn't, we
# leave them empty; action scripts that need them will complain.

if ([string]::IsNullOrWhiteSpace($dashboardsDir)) {
    $templatesDir         = ""
    $outputDir            = ""
    $payloadsDir          = ""
    $homepageTemplatePath = ""
    $sharedTemplatePath   = ""
    $homepageOutputPath   = ""
    $payloadFilePath      = ""
} else {
    # Base subdirectories under Dashboards_Dir
    $templatesDir = Join-Path $dashboardsDir "templates"
    $outputDir    = Join-Path $dashboardsDir "output"
    $payloadsDir  = Join-Path $dashboardsDir "payloads"

    # Homepage template: templates/client/Client-{Label}.json
    $homepageTemplatePath = Join-Path `
        (Join-Path $templatesDir "client") `
        "Client-$dashboardLabel.json"

    # Shared template: templates/shared/{Label}.json
    $sharedTemplatePath = Join-Path `
        (Join-Path $templatesDir "shared") `
        "$dashboardLabel.json"

    # Per-client homepage output: output/{safeName}-{key}.json
    $homepageOutputPath = Join-Path $outputDir "$safeName-$dashboardKey.json"

    # Debug payload file (saved before every homepage upload)
    $payloadFilePath = Join-Path $payloadsDir "$safeName-$dashboardKey-submit-body.json"
}


# ====================================================================
# Section 5 - Return the config hashtable
# ====================================================================
# PowerShell returns the last expression in a script, so this
# hashtable is what "$config = . .\config.ps1" will capture.

@{
    # -- Grafana connection -----------------------------------------
    GrafanaUrl = $grafanaUrl
    Token      = $token

    # -- Client identity --------------------------------------------
    ClientName     = $clientName
    SafeName       = $safeName
    SubscriptionId = $subscriptionId

    # -- Dashboard selection ----------------------------------------
    DashboardKey         = $dashboardKey
    DashboardLabel       = $dashboardLabel
    DashboardType        = $dashboardType
    DashboardTitle       = "$clientName-$dashboardLabel"
    DashboardDescription = "$clientName-$dashboardLabel"

    # -- Homepage folder (per-client subfolder under a parent) ------
    # Structure in Grafana: Client-Homepages / {ClientName} /
    HomepageParentFolder = "Client-Homepages"
    HomepageFolderTitle  = $clientName
    HomepageFolderUid    = ""   # Filled in by create-folder.ps1

    # -- Shared folder (fixed location used by all clients) ---------
    # Structure in Grafana: Shared / Client-Dashboards /
    SharedParentFolder = "Shared"
    SharedChildFolder  = "Client-Dashboards"
    SharedFolderUid    = ""   # Filled in by send-dashboard.ps1 for shared uploads

    # -- Directory paths --------------------------------------------
    DashboardsDir = $dashboardsDir
    TemplatesDir  = $templatesDir
    OutputDir     = $outputDir
    PayloadsDir   = $payloadsDir

    # -- File paths -------------------------------------------------
    HomepageTemplatePath = $homepageTemplatePath
    SharedTemplatePath   = $sharedTemplatePath
    HomepageOutputPath   = $homepageOutputPath
    PayloadFilePath      = $payloadFilePath

    # -- Template variable settings (homepage only) -----------------
    # 0 = visible dropdown, 1 = label only, 2 = fully hidden
    HideSubVariable = 2
}
