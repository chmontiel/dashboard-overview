# create-folder.ps1
# =================
# Ensures the client's subfolder exists under Client-Homepages in Grafana.
#
# STEPS:
#   1. Look up the parent folder (Client-Homepages). It MUST already
#      exist - this script will not create it.
#   2. Check whether a subfolder named after the client already exists
#      under that parent.
#        - If yes: log and re-use its UID.
#        - If no:  create it under the parent.
#
# The resolved folder UID is written back into the config hashtable as
# $Config.HomepageFolderUid so later scripts (send-dashboard.ps1) can
# use it without doing the lookup again.

param(
    [Parameter(Mandatory = $true)]
    [hashtable]$Config
)

# Stop on the first error. If a Grafana call fails, we want to know
# immediately rather than continue with a bad or missing folder UID.
$ErrorActionPreference = "Stop"


# ====================================================================
# HTTP headers for Grafana API calls
# ====================================================================
# GET calls don't need Content-Type. The POST that creates a folder
# does, so we define a second variant for that one call.

$headersGet = @{
    Authorization = "Bearer $($Config.Token)"
    Accept        = "application/json"
}

$headersPost = @{
    Authorization  = "Bearer $($Config.Token)"
    Accept         = "application/json"
    "Content-Type" = "application/json"
}


# ====================================================================
# Step 1 - Look up the parent folder (Client-Homepages)
# ====================================================================
# Grafana's /api/search is a fuzzy title match, so we filter the
# results afterwards for an EXACT title match.

$parentFolderName = $Config.HomepageParentFolder
Write-Host "Looking for parent folder: '$parentFolderName' ..."

$encodedParentName = [uri]::EscapeDataString($parentFolderName)
$searchParentUri   = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedParentName"

$parentSearchResults = Invoke-RestMethod `
    -Method  Get `
    -Uri     $searchParentUri `
    -Headers $headersGet

# Filter the fuzzy results down to an exact match. Where-Object keeps
# only the items where the condition is true.
$parentFolder = $parentSearchResults | Where-Object {
    $_.title -eq $parentFolderName
}

if ($null -eq $parentFolder) {
    throw "Parent folder '$parentFolderName' not found in Grafana. Please create it first."
}

# Wrapping with @() guarantees indexing with [0] works whether the
# result is a single object or an array of matches.
$parentFolderUid = @($parentFolder)[0].uid
Write-Host "  Found parent folder (uid: $parentFolderUid)"


# ====================================================================
# Step 2 - Check whether the client subfolder already exists
# ====================================================================
# We scope the search to the parent folder with the folderUIDs filter
# so we don't match a folder with the same name in a different parent.

$clientFolderName = $Config.HomepageFolderTitle
Write-Host "Checking for existing client subfolder: '$clientFolderName' ..."

$encodedClientName = [uri]::EscapeDataString($clientFolderName)
$searchClientUri   = "$($Config.GrafanaUrl)/api/search?type=dash-folder&query=$encodedClientName&folderUIDs=$parentFolderUid"

$clientSearchResults = Invoke-RestMethod `
    -Method  Get `
    -Uri     $searchClientUri `
    -Headers $headersGet

$existingClientFolder = $clientSearchResults | Where-Object {
    $_.title -eq $clientFolderName
}

if ($null -ne $existingClientFolder) {
    # Folder already exists - re-use its UID and return without POSTing.
    $existingFolderUid = @($existingClientFolder)[0].uid

    Write-Host "  Folder already exists (uid: $existingFolderUid)"
    Write-Host "  Location: $parentFolderName / $clientFolderName"

    $Config.HomepageFolderUid = $existingFolderUid
    return
}


# ====================================================================
# Step 3 - Create the client subfolder
# ====================================================================
# POST /api/folders with title + parentUid in the body.
# ConvertTo-Json -Depth 10 is safe overkill (default depth is 2 which
# can silently drop nested fields).

Write-Host "Creating subfolder: '$clientFolderName' under '$parentFolderName' ..."

$createFolderUri = "$($Config.GrafanaUrl)/api/folders"

$createFolderBody = @{
    title     = $clientFolderName
    parentUid = $parentFolderUid
} | ConvertTo-Json -Depth 10

$createdFolder = Invoke-RestMethod `
    -Method  Post `
    -Uri     $createFolderUri `
    -Headers $headersPost `
    -Body    $createFolderBody

Write-Host "  Created folder '$($createdFolder.title)' (uid: $($createdFolder.uid))"
Write-Host "  Location: $parentFolderName / $($createdFolder.title)"

# Store the new UID on the config so later scripts can upload into it.
$Config.HomepageFolderUid = $createdFolder.uid
