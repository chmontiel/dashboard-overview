# env.base.ps1
# ============
# Environment variables for ALL run.ps1 actions.
# Fill in the values for the actions you plan to run.
# You don't have to fill in everything - each action only validates
# the variables it actually needs.
#
# HOW TO USE:
#   run.ps1 dot-sources this file automatically.
#   You can also load it manually from PowerShell:
#     . .\env.base.ps1
#
# NOTE: In PowerShell, the "$env:" prefix sets an environment variable
# for the CURRENT session. These variables disappear when you close
# the terminal window.


# ====================================================================
# Grafana connection   (required for every action)
# ====================================================================
$env:Grafana_Url = ""   # Base URL, e.g. "https://grafana.example.com"
$env:Token       = ""   # Service account token (needs Editor+ role)


# ====================================================================
# Client identity   (required for every action)
# ====================================================================
# Display name of the client. Folder titles, dashboard titles, and
# other client-specific values are derived from this.
# Example: "Acme Corp"
$env:Client_Name = ""


# ====================================================================
# Azure subscription   (required for homepage dashboards)
# ====================================================================
# Azure subscription ID that the client's homepage dashboards query.
# Only used when Dashboard_Type = "homepage".
$env:Subscription = ""


# ====================================================================
# Dashboards directory   (required for SendDashboard / Onboard)
# ====================================================================
# Path to your local "dashboards" folder which contains:
#   templates/client/  <- homepage (per-client) templates
#   templates/shared/  <- shared (golden) templates
#   output/            <- generated per-client homepage copies
#   payloads/          <- API request bodies saved for debugging
#
# Example: "C:\project\kql-grafana\dashboards"
$env:Dashboards_Dir = ""


# ====================================================================
# Dashboard selection   (required for SendDashboard / DeleteDashboard)
# ====================================================================
# Which dashboard this action targets.
# Examples: "home", "overview", "performance", "infrastructure"
#
# Template file paths are derived from this key:
#   homepage type -> templates/client/Client-{Label}.json
#   shared type   -> templates/shared/{Label}.json
# where {Label} is the key with its first letter capitalized
# (e.g. "home" -> "Home").
$env:Dashboard_Key = ""


# ====================================================================
# Dashboard type   (required for SendDashboard / Onboard)
# ====================================================================
# Must be exactly one of:
#
#   "homepage"  -> per-client dashboard. The script strips the UID,
#                  updates the title, description, and subscription
#                  variable, then uploads into the client's subfolder
#                  under Client-Homepages.
#
#   "shared"    -> golden template. UID is preserved exactly as-is.
#                  Uploads into Shared/Client-Dashboards. Reused by
#                  all clients; homepage dashboards link to these.
$env:Dashboard_Type = ""
